import 'package:car_rent_app_master/pages/homePage.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    
    return const MaterialApp(
   
    child: ElevatedButton( 
          child: Icon( 
            Icons., 
            size: size, 
          ), 
          style: ElevatedButton.styleFrom( 
            primary: Theme.of(context)., 
            shape: CircleBorder(), 
            padding: EdgeInsets.all(2), 
          ), 
          onPressed: () => {const HomePageCarRentApp()}, 
        ),
      );
  }
}
