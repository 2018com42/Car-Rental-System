import 'package:flutter/material.dart';

class HomePageCarRentApp extends StatefulWidget {
  const HomePageCarRentApp({super.key});

  @override
  State<HomePageCarRentApp> createState() => _HomePageCarRentAppState();
}

class _HomePageCarRentAppState extends State<HomePageCarRentApp> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Choose Your Car'),
      iconTheme: const IconThemeData( ),
      actions: [ActionIconTheme(
        data:Icons., 
      child:build(context))]
      ),
      body:Column(
        children: [
          final List<String> _cars = ['Toyota', 'Honda', 'Ford'];
          final TextEditingController _textController = TextEditingController();

  void _addCar() {
    if (_textController.text.isEmpty) {
      return;
    }

    setState(() {
      _cars.add(_textController.text);
    });

    _textController.clear();
    Navigator.of(context).pop();
  }

  void _showAddCarDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Add a new car'),
          content: TextField(
            controller: _textController,
            decoration: InputDecoration(hintText: 'Enter car name'),
          ),
          actions: <Widget>[
            TextButton(
              child: Text('Cancel'),
              onPressed: () {
                _textController.clear();
                Navigator.of(context).pop();
              },
            ),
            TextButton(
              child: Text('Add'),
              onPressed: _addCar,
            ),
          ],
        );
      },
    ),
    }
        ],


      ),
    );
  }
}