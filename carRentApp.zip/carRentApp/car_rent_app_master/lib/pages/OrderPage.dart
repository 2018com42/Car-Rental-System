import 'package:flutter/material.dart';
import 'package:stripe_payment/stripe_payment.dart';

class OrderPage extends StatefulWidget {
  const OrderPage({super.key});

  @override
  State<OrderPage> createState() => _OrderPageState();
}

class _OrderPageState extends State<OrderPage> {
  @override
  void initState() {
    super.initState();
    var StripePayment;
    StripePayment.setOptions(
      StripeOptions(
        publishableKey: "your_publishable_key",
        merchantId: "Test",
        androidPayMode: 'test',
      ),
    );
  }

  void bookCar() {
    // Logic to book the car
    // This is just a placeholder for your booking logic
       print("Car booked successfully");
  }

  Future<void> payViaCard(BuildContext context) async {
    try {
      var StripePayment;
      var paymentMethod = await StripePayment.paymentRequestWithCardForm(
        CardFormPaymentRequest(),
      );
      print("Payment Method: ${paymentMethod.id}");
      // Logic to process the payment using the payment method
      // This is a placeholder for your payment processing logic
      print("Payment successful");
    } catch (e) {
      print("Payment failed: $e");
    }
  }
  Widget build(BuildContext context) {
    return Scaffold(
       //This page describe booking car,order car using online booking methods details
       appBar: AppBar(
        title: const Text('Order Page'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
           const Text(
              'Book Your Car',
              style: TextStyle(fontSize: 24),
            ),
           const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                bookCar();
              },
              child: const Text('Book Car'),
            ),
           const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                payViaCard(context);
              },
              child: const Text('Pay Now'),
            ),
          ],
        ),
      ),
    );
  }
  
  StripeOptions({required String publishableKey, required String merchantId, required String androidPayMode}) {}
  
  CardFormPaymentRequest() {}
}

