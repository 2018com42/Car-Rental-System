package com.example.car_rent_app_master

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
